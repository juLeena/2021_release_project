using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    public GameObject Camera;
    private Vector3 Camera_Move_UD,Camera_Move_LR;
    // Start is called before the first frame update
    void Start()
    {
        Camera_Move_UD = new Vector3(0.0f, 0.0f, 1.0f);
        Camera_Move_LR = new Vector3(1.0f, 0.0f, 0.0f);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W) && GameObject.Find("Main Camera").GetComponent<NewBehaviourScript>().check!=1)
        {
            Camera.transform.position += Camera_Move_UD;
        }
        if (Input.GetKey(KeyCode.A) && GameObject.Find("Main Camera").GetComponent<NewBehaviourScript>().check != 1)
        {
            Camera.transform.position -= Camera_Move_LR;
        }
        if (Input.GetKey(KeyCode.S) && GameObject.Find("Main Camera").GetComponent<NewBehaviourScript>().check != 1)
        {
            Camera.transform.position -= Camera_Move_UD;
        }
        if (Input.GetKey(KeyCode.D) && GameObject.Find("Main Camera").GetComponent<NewBehaviourScript>().check != 1)
        {
            Camera.transform.position += Camera_Move_LR;
        }
    }
}
