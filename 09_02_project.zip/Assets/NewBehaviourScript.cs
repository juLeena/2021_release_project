using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField]
    private GameObject BoxPrefab;//�ڽ� enemy
    [SerializeField]
    private GameObject GuPrefab;//�� enemy
    [SerializeField]
    private GameObject sight1, sight2, sight3, sight4, Player, Plane1, Plane2;//player, field 2��, �þ� ������ ������Ʈ 4��
    System.Random random = new System.Random();
    public int i, flag = 0,x,count=0,org_point,enemy_num,check=0,enemys=0;
    float timer;
    float waitingTime;
    public Transform Target;
    public float Zoom;
    private Transform tr;
    private Vector3 CameraMove, posChange, scaleChange, org_scale1, org_scale2, org_scale3, org_scale4, org_pos1, org_pos2, org_pos3, org_pos4, org_pos5, org_pos6;
    private Vector3 Plane_size1, Plane_size2;
    List<GameObject> Objects2 = new List<GameObject>();
    public List<GameObject> Objects = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {

        tr = GetComponent<Transform>();
        timer = 0f;
        waitingTime = 0.014f;
        scaleChange = new Vector3(0.0f, 0.0f, 0.9f);
        posChange = new Vector3(0.0f, -0.75f, 0.0f);
        org_scale1 = sight1.transform.localScale;
        org_scale2 = sight2.transform.localScale;
        org_scale3 = sight3.transform.localScale;
        org_scale4 = sight4.transform.localScale;
        org_pos1 = sight1.transform.position;
        org_pos2 = sight2.transform.position;
        org_pos3 = sight3.transform.position;
        org_pos4 = sight4.transform.position;
        org_pos5 = tr.position;
        org_pos6 = Player.transform.position;
    }
    // Update is called once per frame
    void Update()
    {

        timer += Time.deltaTime;
        if (timer > waitingTime)
        {
            if(count==75)
            {
                Destroy(Objects2[0]);
                Objects2.RemoveAt(0);
                tr.position = org_pos5;
                count = 0;
                flag = 0;
                sight1.transform.localScale = org_scale1;
                sight2.transform.localScale = org_scale2;
                sight3.transform.localScale = org_scale3;
                sight4.transform.localScale = org_scale4;
                Player.transform.position = org_pos6;
                check = 0;
            }
            if (flag == 0)
            {
                if (random.Next(1, 3) == 1)
                {
                    Objects2.Add(Instantiate(Plane1, new Vector3(0, 0, 0), Quaternion.identity) as GameObject);
                    Plane_size1 = Plane1.transform.localScale;
                    Plane_size2 = Plane1.transform.localScale*5 - new Vector3(3,0,3);
                }
                else
                {
                    Objects2.Add(Instantiate(Plane2, new Vector3(0, 0, 0), Quaternion.identity) as GameObject);
                    Plane_size1 = Plane2.transform.localScale;
                    Plane_size2 = Plane2.transform.localScale*5 - new Vector3(3, 0, 3);
                }
                enemy_num = random.Next(1,6);
                for (i = 0; i < enemy_num; i++)
                {
                    if (random.Next(1, 3) == 1)
                    {
                        Objects.Add(Instantiate(GuPrefab, new Vector3(random.Next((int)(-Plane_size2.x), (int)(Plane_size2.x)), 1, random.Next((int)(-Plane_size2.z), (int)(Plane_size2.z))), Quaternion.identity) as GameObject);
                    }
                    else
                    {
                        Objects.Add(Instantiate(BoxPrefab, new Vector3(random.Next((int)(-Plane_size2.x), (int)(Plane_size2.x)), 1, random.Next((int)(-Plane_size2.z), (int)(Plane_size2.z))), Quaternion.identity) as GameObject);
                    }
                }
                flag = 1;
                x = Objects.Count;
            }
            if (x==enemys)
            {
                if(Input.GetKey(KeyCode.W) && check==0)
                {
                    print(Player.transform.position.z);
                    CameraMove = new Vector3(-tr.position.x / 75, 0.0f, (Plane_size1.z-tr.position.z/5)/15);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.A) && check == 0)
                {
                    CameraMove = new Vector3(-(Plane_size1.x + tr.position.x/5) / 15, 0.0f, -tr.position.z / 75);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.S) && check == 0)
                {
                    CameraMove = new Vector3(-tr.position.x / 75, 0.0f, -(Plane_size1.z + tr.position.z/5) / 15);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.D) && check == 0)
                {
                    CameraMove = new Vector3((Plane_size1.x - tr.position.x/5) / 15, 0.0f, -tr.position.z / 75);
                    check = 1;
                }
                if (count<70 && check==1)
                {
                    tr.position += CameraMove;
                    count += 1;
                    sight1.transform.localScale += scaleChange;
                    sight2.transform.localScale += scaleChange;
                    sight3.transform.localScale += scaleChange;
                    sight4.transform.localScale += scaleChange;
                }
                if(count>=70)
                {
                    count += 1;
                }
            }
            timer = 0;
        }
    }
}
