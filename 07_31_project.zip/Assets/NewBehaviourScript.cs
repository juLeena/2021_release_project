using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField]
    private GameObject BoxPrefab;
    [SerializeField]
    private GameObject GuPrefab;
    [SerializeField]
    private GameObject sight1, sight2, sight3, sight4, Player;
    int[] pointX = new int[] {};
    int[] pointZ = new int[] {};
    System.Random random = new System.Random();
    public Material[] materials;
    int i, flag = 0,x,count=0,org_point,enemy_num,check=0;
    float timer;
    float waitingTime;
    float a;
    public Transform Target;
    public float Zoom;
    private Transform tr;
    private Vector3 CameraMove, posChange, scaleChange, org_scale1, org_scale2, org_scale3, org_scale4, org_pos1, org_pos2, org_pos3, org_pos4, org_pos5, org_pos6;
    List<GameObject> Objects = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        tr = GetComponent<Transform>();
        timer = 0f;
        waitingTime = 0.014f;
        a = 1.0f;
        scaleChange = new Vector3(0.0f, 0.0f, 0.9f);
        posChange = new Vector3(0.0f, -0.75f, 0.0f);
        org_scale1 = sight1.transform.localScale;
        org_scale2 = sight2.transform.localScale;
        org_scale3 = sight3.transform.localScale;
        org_scale4 = sight4.transform.localScale;
        org_pos1 = sight1.transform.position;
        org_pos2 = sight2.transform.position;
        org_pos3 = sight3.transform.position;
        org_pos4 = sight4.transform.position;
        org_pos5 = tr.position;
        org_pos6 = Player.transform.position;
    }
    // Update is called once per frame
    void Update()
    {

        timer += Time.deltaTime;
        if (timer > waitingTime)
        {
            if(count==75)
            {
                tr.position = org_pos5;
                count = 0;
                flag = 0;
                a = 0.8f;
                sight1.transform.localScale = org_scale1;
                sight2.transform.localScale = org_scale2;
                sight3.transform.localScale = org_scale3;
                sight4.transform.localScale = org_scale4;
                sight1.transform.position = org_pos1;
                sight2.transform.position = org_pos2;
                sight3.transform.position = org_pos3;
                sight4.transform.position = org_pos4;
                Player.transform.position = org_pos6;
                check = 0;
            }
            if (flag == 0)
            {
                enemy_num = random.Next(1,6);
                for (i = 0; i < enemy_num; i++)
                {
                    if (random.Next(1, 3) == 1)
                    {
                        Objects.Add(Instantiate(GuPrefab, new Vector3(random.Next(-47, 47), 1, random.Next(-47, 47)), Quaternion.identity) as GameObject);
                    }
                    else
                    {
                        Objects.Add(Instantiate(BoxPrefab, new Vector3(random.Next(-47, 47), 1, random.Next(-47, 47)), Quaternion.identity) as GameObject);
                    }
                }
                flag = 1;
                x = Objects.Count - 1;
            }
            if (Input.GetKey(KeyCode.Space) && x >= 0)
            {
                Destroy(Objects[x]);
                Objects.RemoveAt(x);
                x -= 1;
            }
            if(x==-1)
            {
                if(Input.GetKey(KeyCode.W) && check==0)
                {
                    CameraMove = new Vector3(0.0f, 0.0f, 0.66f);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.A) && check == 0)
                {
                    CameraMove = new Vector3(-0.66f, 0.0f, 0.0f);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.S) && check == 0)
                {
                    CameraMove = new Vector3(0.0f, 0.0f, -0.66f);
                    check = 1;
                }
                if (Input.GetKey(KeyCode.D) && check == 0)
                {
                    CameraMove = new Vector3(0.66f, 0.0f, 0.0f);
                    check = 1;
                }
                if (count<70 && check==1)
                {
                    Vector3 TargetDist = tr.position - Target.position;
                    TargetDist = Vector3.Normalize(TargetDist);
                    tr.position -= (TargetDist * a * Zoom);
                    Player.transform.position += CameraMove;
                    tr.position += CameraMove;
                    count += 1;
                    a += 0.015f;
                    sight1.transform.localScale += scaleChange;
                    sight2.transform.localScale += scaleChange;
                    sight3.transform.localScale += scaleChange;
                    sight4.transform.localScale += scaleChange;
                    sight1.transform.position += posChange+CameraMove;
                    sight2.transform.position += posChange + CameraMove;
                    sight3.transform.position += posChange + CameraMove;
                    sight4.transform.position += posChange + CameraMove;
                }
                if(count>=70)
                {
                    count += 1;
                }
            }
            timer = 0;
        }
    }
}
