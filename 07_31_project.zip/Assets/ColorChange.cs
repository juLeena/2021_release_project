using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ColorChange : MonoBehaviour
{
    Renderer enemy;
    System.Random rand = new System.Random();  
    // Start is called before the first frame update
    void Start()
    {
        enemy = gameObject.GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
